getwd()
setwd("C:\\Users\\IT24100484\\Desktop\\IT24100484")
getwd()

# Question 01
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

# Question 02
str(branch_data)

# Question 03
boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales", outline = TRUE, horizontal = TRUE)

# Question 04
advertising_summery <- summary(branch_data$Advertising)
print(advertising_summery)

advertising_iqr <- IQR(branch_data$Advertising)
print(paste("IQR for Advertising:", advertising_iqr))

# Question 05
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  if(length(outliers) == 0) {
    return("No outliers detected")
  } else {
    return(sort(outliers))
  }
}

years_outliers <- find_outliers(branch_data$Years)
print(paste("Outliers in Years variable:", paste(years_outliers, collapse=", ")))