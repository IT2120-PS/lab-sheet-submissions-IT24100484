setwd("/Users/nuransahabandu/Documents/R/IT24100484")
getwd()


data<-read.table("Data.txt",header=TRUE,sep=",")
data


fix(data)

attach(data)

names(data)<-c("X1","X2")


attach(data)


fix(data)


hist(X2,main="Histogram for the number of shareholders")


histogram<-hist(X2,main="Histogram for the number of shareholders",breaks=seq(130,270,length=8),right=FALSE)


?hist

histogram$breaks

breaks<-round(histogram$breaks)
breaks

freq<-histogram$counts
freq

mids<-histogram$mids
mids

classes<-c()

for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[",breaks[i],",",breaks[i+1],"]")
}

classes


cbind(Classes = classes, Frequency = freq)

lines(mids,freq)

plot(mids,freq,types='1',main="Frequency polygon for shareholders",xlab="Shareholders",ylab="Frequency",ylim=c(0,max(freq)))

cum.freq<-cumsum(freq)

new<-c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}


plot(breaks,new,type='l',main="Cumulative Frequency Diagram for Shareholders",xlab="Shareholders",ylab = "Cumulative Frequency",
     ylim=c(0,max(cum.freq)))

