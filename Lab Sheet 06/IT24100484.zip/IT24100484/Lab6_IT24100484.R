setwd("/Users/nuransahabandu/Documents/R/IT24100484")

#Question 01
#Part 1

#i)
#Binomial Distribution
#Here, random variable X has binomial distribution with n=44 and p-0.92

#ii)
dbinom(40,44,0.92)


#iii)
pbinom(35,44,0.92,lower.tail=TRUE)


#iv)
1-pbinom(37,44,0.92,lower.tail=TRUE)
#or
pbinom(37,44,0.92,lower.tail=FALSE)


#v)
pbinom(42,44,0.92,lower.tail=TRUE)-pbinom(39,44,0.92,lower.tail=TRUE)



#Question 02

#i)
#Number of babies born in a hospital on a given day

#ii)
#Poisson Distribution
#Here random variable X has poisson distribution with lambda=5

#iii)
dpois(6,5)

#iv)
ppois(6,5,lower.tail=FALSE)


#EXERCISE

#Question 01

#i)
#Binomial Distribution

#ii)
1-pbinom(46,50,0.85,lower.tail=TRUE)

#Question 02

#i)
#Number of calls received by the call centre per hour

#ii)
#Poisson Distribution

#iii)
dpois(15,12)

